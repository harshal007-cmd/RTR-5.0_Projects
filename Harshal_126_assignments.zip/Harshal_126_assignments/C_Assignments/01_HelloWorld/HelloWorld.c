#include<stdio.h>

int main(void)
{
	printf("Hello World: RTR 5.0");
	return 0;
}
